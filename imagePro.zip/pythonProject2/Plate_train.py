import os
import cv2 as cv
import numpy as np

DIR = r'images'

haar_cascade = cv.CascadeClassifier('detect.xml')

features = []
labels = []


def create_train():

  for img in os.listdir(DIR):
            img_path = os.path.join(DIR, img)

            img_array = cv.imread(img_path)
            if img_array is None:
                continue

            gray = cv.cvtColor(img_array, cv.COLOR_BGR2GRAY)

            plate_rect = haar_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=4)

            for (x, y, w, h) in plate_rect:
                plate_roi = gray[y:y + h, x:x + w]
                features.append(plate_roi)
                labels.append(1)


create_train()
print('Training done ---------------')

features = np.array(features, dtype='object')
labels = np.array(labels)
#face.LBPHFaceRecognizer_create()
Plate_recognizer = cv.face.LBPHFaceRecognizer_create()
# Train the Recognizer on the features list and the labels list
Plate_recognizer.train(features,labels)

Plate_recognizer.save('plate_trained.yml')
np.save('features.npy', features)
