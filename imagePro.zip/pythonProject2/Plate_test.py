#pylint:disable=no-member
import easyocr as easyocr
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt

haar_cascade = cv.CascadeClassifier('detect.xml')

# features = np.load('features.npy', allow_pickle=True)
# labels = np.load('labels.npy')

face_recognizer = cv.face.LBPHFaceRecognizer_create()
face_recognizer.read('plate_trained.yml')
img = cv.imread(r'test2.jpg')
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
blank = np.zeros(gray.shape, np.uint8)
cv.imshow('blank',blank)
cv.imshow('Car', gray)

# Detect the face in the image
faces_rect = haar_cascade.detectMultiScale(gray, 1.4, 4)

for (x,y,w,h) in faces_rect:
    plate_roi = gray[y:y+h,x:x+w]
    label, confidence = face_recognizer.predict(plate_roi)
    print(f' confidence of {confidence}')
    cv.rectangle(img, (x,y), (x+w,y+h), (0,255,0), thickness=2)
    mask=cv.rectangle(blank, (x,y), (x+w,y+h),255, -1)
cv.imshow('maskkk',mask)
new_image = cv.bitwise_and(img, img, mask=mask)
cv.imshow('Detected plate', img)
cv.imshow('mask', new_image)
reader = easyocr.Reader(['en'])
result = reader.readtext(new_image)
print(result)
cv.waitKey(0)



